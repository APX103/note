# CV610 音乐触摸 Demo（2026-09-09 实板验证）

LVGL v9.3.0 官方 Music Demo，使用自带分页布局适配 JD9853 240×320 + Hynitron 触摸。通过已验证的官方 x86 Docker 镜像在 ARM Mac 上编译，libdrm 2.4.124 静态链接，运行时仅依赖板载 musl。

- `main.c`：DRM、evdev 和音乐界面入口。
- `lv_conf.h`：小屏分页配置；无实际音频播放。
- `build.sh`：容器内执行的构建脚本，容器将当前仓库挂载至 `/work`。
- `upload.py`：通过 Debug 串口上传 gzip 包，校验两个 SHA-256 后切换 Demo。
- `check.py` / `grab.c`：日志、模拟触摸和 DRM 截图验证。

运行文件为板上的 `/tmp/cv610_music`，日志 `/tmp/codex-music.log`；未更改开机脚本。恢复原界面：先 `killall -TERM cv610_music`，再 `/bin/samples_panel &`。重启也会运行原开机 Demo。

向左/右滑专辑封面切换曲目；向上滑动到播放控制页，再向上滑进入曲目列表。这是官方 UI 演示，不会发声，也没有接入模型或云端服务。

源码：https://github.com/lvgl/lvgl/tree/v9.3.0/demos/music
