#!/bin/sh
set -eu
export PATH=/opt/toolchains/gcc-10.3-arm-musl-x86-linux-26.06.1/arm-v01c02-linux-musleabi-gcc/bin:$PATH
cd /work/.docker-validation
mkdir -p music-build
cat > music-build/arm.ini <<'EOF'
[binaries]
c = 'arm-v01c02-linux-musleabi-gcc'
ar = 'arm-v01c02-linux-musleabi-ar'
strip = 'arm-v01c02-linux-musleabi-strip'
pkgconfig = 'pkg-config'
[host_machine]
system = 'linux'
cpu_family = 'arm'
cpu = 'armv7'
endian = 'little'
[built-in options]
c_args = ['-Os', '-march=armv7-a', '-mfpu=neon-vfpv4', '-mfloat-abi=softfp']
c_link_args = ['-march=armv7-a', '-mfpu=neon-vfpv4', '-mfloat-abi=softfp']
EOF
if [ ! -f music-build/drm/build.ninja ]; then
 meson setup music-build/drm ui-deps/libdrm-2.4.124 --cross-file music-build/arm.ini --prefix="$PWD/music-build/install" --libdir=lib --default-library=static --auto-features=disabled -Dtests=false -Dbuildtype=minsize
fi
ninja -C music-build/drm install
cmake -S music-demo -B music-build/app -G Ninja -DCMAKE_SYSTEM_NAME=Linux -DCMAKE_SYSTEM_PROCESSOR=arm -DCMAKE_C_COMPILER=arm-v01c02-linux-musleabi-gcc -DCMAKE_CXX_COMPILER=arm-v01c02-linux-musleabi-g++ -DDRM_PREFIX="$PWD/music-build/install"
cmake --build music-build/app -j 6
arm-v01c02-linux-musleabi-readelf -h -l music-build/app/cv610_music
sha256sum music-build/app/cv610_music
ls -lh music-build/app/cv610_music
gzip -c music-build/app/cv610_music > music-build/cv610_music.gz
