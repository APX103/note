#include "lvgl.h"
#include "demos/lv_demos.h"
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

static volatile sig_atomic_t running = 1;
static void stop(int sig) { (void)sig; running = 0; }
static void touch_event(lv_event_t *event)
{
    lv_point_t point;
    lv_indev_get_point(lv_event_get_current_target(event), &point);
    printf("[touch] pressed %d,%d\n", (int)point.x, (int)point.y);
}
int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    struct sigaction action = {0};
    action.sa_handler = stop;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGTERM, &action, NULL) || sigaction(SIGINT, &action, NULL)) return 1;
    lv_init();
    lv_display_t *display = lv_linux_drm_create();
    if (!display) return 1;
    lv_linux_drm_set_file(display, "/dev/dri/card0", -1);
    int width = lv_display_get_horizontal_resolution(display);
    int height = lv_display_get_vertical_resolution(display);
    printf("[display] %dx%d\n", width, height);
    if (width != 240 || height != 320) return 2;
    lv_indev_t *touch = lv_evdev_create(LV_INDEV_TYPE_POINTER, "/dev/input/event0");
    if (!touch) return 3;
    lv_indev_set_display(touch, display);
    lv_indev_add_event_cb(touch, touch_event, LV_EVENT_PRESSED, NULL);
    FILE *backlight = fopen("/sys/class/backlight/backlight/brightness", "w");
    if (backlight) { fputs("100", backlight); fclose(backlight); }
    lv_demo_music();
    puts("[music] ready: visual demo, no audio playback");
    while (running) {
        unsigned delay = lv_timer_handler();
        usleep((delay > 50 ? 50 : delay) * 1000);
    }
    lv_deinit();
    return 0;
}
