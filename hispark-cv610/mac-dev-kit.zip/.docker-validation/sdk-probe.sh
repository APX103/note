#!/bin/bash
set -eu
date -u
uname -m
if command -v file >/dev/null; then file /bin/bash; fi
compiler=$(command -v arm-v01c02-linux-musleabi-gcc || true)
if [ -z "$compiler" ]; then
  compiler=$(find /opt/toolchains -type f -name arm-v01c02-linux-musleabi-gcc -print -quit)
fi
test -n "$compiler"
compiler_dir=$(dirname "$compiler")
export PATH="$compiler_dir:$PATH"
if command -v file >/dev/null; then file "$compiler"; fi
"$compiler" --version
"$compiler" -dumpmachine
mkdir -p /work/probe
cd /work/probe
cat > probe.c <<'C'
#include <stdio.h>
#if !defined(__arm__) || __SIZEOF_POINTER__ != 4
#error Expected 32-bit ARM target
#endif
int main(void) { puts("CV610 ARMv7 compiler probe"); return 0; }
C
"$compiler" -march=armv7-a -mfpu=neon-vfpv4 -mfloat-abi=softfp probe.c -o probe-armv7
if command -v file >/dev/null; then file probe-armv7; fi
if command -v readelf >/dev/null; then readelf -h -l probe-armv7; fi
cat > probe.cpp <<'CPP'
#include <vector>
#include <cstdio>
int main() { std::vector<int> values{1, 2, 3}; std::printf("%zu\n", values.size()); }
CPP
"${compiler%gcc}g++" -std=c++11 -march=armv7-a -mfpu=neon-vfpv4 -mfloat-abi=softfp probe.cpp -o probe-cpp-armv7
if command -v file >/dev/null; then file probe-cpp-armv7; fi
sha256sum probe-armv7 probe-cpp-armv7
echo SDK_COMPILER_PROBE_PASS
