"""Task-local serial transport; commands and individual files only."""
import base64, gzip, hashlib, os, re, secrets, select, shlex, termios, time, tty
from pathlib import Path
class Board:
 def __enter__(self):
  self.fd=os.open(os.environ['CV610_PORT'],os.O_RDWR|os.O_NOCTTY|os.O_NONBLOCK)
  self.old=termios.tcgetattr(self.fd); tty.setraw(self.fd)
  a=termios.tcgetattr(self.fd); a[4]=a[5]=termios.B115200; a[2]=termios.CS8|termios.CREAD|termios.CLOCAL
  termios.tcsetattr(self.fd,termios.TCSANOW,a); self.write(b'\rstty -echo\r'); self.read(0.3); return self
 def write(self,data):
  while data:
   if select.select([],[self.fd],[],1)[1]:
    try:data=data[os.write(self.fd,data):]
    except BlockingIOError:pass
 def read(self,seconds,marker=None):
  data=bytearray(); end=time.monotonic()+seconds
  while time.monotonic()<end:
   if select.select([self.fd],[],[],.05)[0]:
    try:data.extend(os.read(self.fd,8192))
    except BlockingIOError:pass
   if marker and marker in data:break
  return bytes(data)
 def run(self,cmd,timeout=10):
  token=secrets.token_hex(6); marker=('CV610_DONE_'+token).encode()
  # An echoed command cannot match the completed printf output.
  self.write((cmd.rstrip().rstrip(';')+"\rprintf '\\nCV610_DONE_%s\\n' "+token+'\r').encode())
  data=re.sub(r'\r+\n','\r\n',self.read(timeout,marker).decode(errors='replace'))
  if marker.decode() not in data:raise TimeoutError(data[-2000:])
  return data
 def push(self,local,remote):
  data=Path(local).read_bytes(); compressed=gzip.compress(data); q=shlex.quote(remote)
  digest=hashlib.sha256(data).hexdigest()
  if digest in self.run('sha256sum '+q+' 2>/dev/null'):
   print(remote+': already verified',flush=True); return
  self.write(("PS2=''; base64 -d <<'CV610_PAYLOAD_END' | gzip -dc > "+q+".new\r").encode()); self.read(.2)
  payload=base64.encodebytes(compressed)
  for pos in range(0,len(payload),768):
   self.write(payload[pos:pos+768]); self.read(.07)
   if pos%76800==0:print(f'{remote}: {pos*100//len(payload)}%',flush=True)
  self.write(b'CV610_PAYLOAD_END\r'); self.read(.5)
  digest=hashlib.sha256(data).hexdigest()
  if digest not in self.run('sha256sum '+q+'.new'):raise RuntimeError('checksum mismatch '+remote)
  print(self.run('mv '+q+'.new '+q),flush=True)
 def pull(self,remote,local,timeout=50):
  out=self.run('echo FILE_BEGIN; gzip -c '+shlex.quote(remote)+' | base64; echo FILE_END',timeout)
  data=gzip.decompress(base64.b64decode(out.split('FILE_BEGIN\r\n',1)[1].split('FILE_END',1)[0])); Path(local).write_bytes(data)
  assert hashlib.sha256(data).hexdigest() in self.run('sha256sum '+shlex.quote(remote))
 def __exit__(self,*args):
  self.write(b'stty echo\r'); self.read(.15); termios.tcsetattr(self.fd,termios.TCSANOW,self.old); os.close(self.fd)
if __name__=='__main__':
 import sys
 with Board() as b:
  for cmd in sys.argv[1:]:print(b.run(cmd),flush=True)
